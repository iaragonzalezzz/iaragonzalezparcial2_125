package NavesEspaciales125;

import java.io.Serializable;

public class NaveEspacial implements Comparable<NaveEspacial>, CSVSerializable, Serializable {
    private int id;
    private String nombre;
    private Categoria categoria;
    private int capacidadTripulacion;

    public NaveEspacial(int id, String nombre, int capacidadTripulacion, Categoria categoria) {
        this.id = id;
        this.nombre = nombre;
        this.categoria = categoria;
        this.capacidadTripulacion = capacidadTripulacion;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;  
    }

    public int getCapacidadTripulacion() {
        return capacidadTripulacion;
    }

    @Override
    public int compareTo(NaveEspacial o) {
        return Integer.compare(this.id, o.id);
    }

    @Override
    public String toString() {
        return String.format("Nave [ID: %d, Nombre: %s, Categoria: %s, Capacidad: %d]",
                id, nombre, categoria, capacidadTripulacion);
    }

    @Override
    public String toCSV() {
        return String.format("%d,%s,%s,%d", id, nombre, categoria, capacidadTripulacion);
    }

    public static NaveEspacial fromCSV(String csv) {
        String[] partes = csv.split(",");
        return new NaveEspacial(Integer.parseInt(partes[0]), partes[1], Integer.parseInt(partes[3]), Categoria.valueOf(partes[2]));
    }
}
