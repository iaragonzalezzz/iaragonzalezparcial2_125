package NavesEspaciales125;

public interface CSVSerializable {
    String toCSV();
}
