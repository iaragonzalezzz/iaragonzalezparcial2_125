package NavesEspaciales125;

import java.io.*;
import java.util.*;
import java.util.function.Predicate;
import java.util.function.Function;
import java.util.function.Consumer;

public class Inventario<T extends Comparable<T>> {
    private List<T> elementos;

    public Inventario() {
        elementos = new ArrayList<>();
    }

    public void agregar(T elemento) {
        elementos.add(elemento);
    }

    public void eliminar(T elemento) {
        elementos.remove(elemento);
    }

    public void paraCadaElemento(Consumer<T> accion) {
        for (T elemento : elementos) {
            accion.accept(elemento);
        }
    }

    public List<T> filtrar(Predicate<T> criterio) {
        List<T> filtrados = new ArrayList<>();
        for (T elemento : elementos) {
            if (criterio.test(elemento)) {
                filtrados.add(elemento);
            }
        }
        return filtrados;
    }

    public void ordenar() {
        Collections.sort(elementos); 
    }

    public void ordenar(Comparator<T> comparador) {
        elementos.sort(comparador);
    }

    public void guardarEnArchivo(String nombreArchivo) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(nombreArchivo))) {
            oos.writeObject(elementos);
        }
    }

    public void cargarDesdeArchivo(String nombreArchivo) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(nombreArchivo))) {
            elementos = (List<T>) ois.readObject();
        }
    }

    public void guardarEnCSV(String nombreArchivo) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(nombreArchivo))) {
            for (T elemento : elementos) {
                writer.write(((CSVSerializable) elemento).toCSV()); 
                writer.newLine();
            }
        }
    }

    public void cargarDesdeCSV(String nombreArchivo, Function<String, T> fromCSV) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(nombreArchivo))) {
            String line;
            while ((line = reader.readLine()) != null) {
                elementos.add(fromCSV.apply(line));
            }
        }
    }

    public void transformar(Function<T, T> transformacion) {
        for (int i = 0; i < elementos.size(); i++) {
            elementos.set(i, transformacion.apply(elementos.get(i)));
        }
    }
}