
package NavesEspaciales125;

public enum Categoria {
    CIENTIFICA,
    TRANSPORTE,
    MILITAR
}


